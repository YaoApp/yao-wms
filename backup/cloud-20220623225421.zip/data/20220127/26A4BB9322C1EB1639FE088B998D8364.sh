export https_proxy=http://192.168.31.127:7890 http_proxy=http://192.168.31.127:7890 all_proxy=socks5://192.168.31.127:7890
export https_proxy=http://192.168.31.127:7890 http_proxy=http://192.168.31.127:7890 all_proxy=socks5://192.168.31.127:7890

export https_proxy=http://127.0.0.1:7890 http_proxy=http://127.0.0.1:7890 all_proxy=socks5://127.0.0.1:7890